import alphabeter

alphabeter.setBackGroundColor("red")
alphabeter.setForeGroundColor("orange")
alphabeter.setTxt("this is random text")
alphabeter.setStartX(200)
alphabeter.setFontSize(10)
alphabeter.setSpeed(200)
alphabeter.printData()