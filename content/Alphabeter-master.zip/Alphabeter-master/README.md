# Alphabeter
Python library to draw alphabets using turtle with customisation

Download The Alphabeter.py module.

Include it in your project

import it and use.

Follow the other two samples (withgui.py and withoutgui.py as reference to use it with and without tkinter.
