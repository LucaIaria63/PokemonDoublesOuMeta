import turtle
from tkinter import *
from tkinter import  ttk






def printBlank():
    turtle.color(str(bg.get()))
    turtle.forward(30)


def printA(color):
    turtle.color(color)
    turtle.left(90)
    turtle.forward(100)
    turtle.right(90)
    turtle.forward(50)
    turtle.right(90)
    turtle.forward(50)
    turtle.right(90)
    turtle.forward(50)
    turtle.left(180)
    turtle.forward(50)
    turtle.right(90)
    turtle.forward(50)
    turtle.left(90)


def printB(color):
    turtle.color(color)
    turtle.left(90)
    turtle.forward(100)
    turtle.right(90)
    turtle.forward(50)
    turtle.right(90)
    turtle.forward(50)
    turtle.right(90)
    turtle.forward(50)
    turtle.right(180)
    turtle.forward(50)
    turtle.right(90)
    turtle.forward(50)
    turtle.right(90)
    turtle.forward(50)
    turtle.left(180)
    turtle.forward(50)

def printC(color):
    turtle.color(color)
    turtle.forward(50)
    turtle.left(180)
    turtle.forward(50)
    turtle.right(90)
    turtle.forward(100)
    turtle.right(90)
    turtle.forward(50)
    turtle.right(90)
    turtle.color(str(bg.get()))
    turtle.forward(100)
    turtle.left(90)

def printD(color):
    turtle.color(color)
    turtle.forward(50)
    turtle.left(180)
    turtle.forward(50)
    turtle.right(90)
    turtle.forward(100)
    turtle.right(90)
    turtle.forward(50)
    turtle.right(90)
    turtle.forward(100)
    turtle.left(90)


def printE(color):
    turtle.color(color)
    turtle.forward(50)
    turtle.left(180)
    turtle.forward(50)
    turtle.right(90)
    turtle.forward(50)
    turtle.right(90)
    turtle.forward(50)
    turtle.right(180)
    turtle.forward(50)
    turtle.right(90)
    turtle.forward(50)
    turtle.right(90)
    turtle.forward(50)
    turtle.right(90)
    turtle.color(str(bg.get()))
    turtle.forward(100)
    turtle.left(90)

def printF(color):
    turtle.color(color)
    turtle.left(90)
    turtle.forward(50)
    turtle.right(90)
    turtle.forward(50)
    turtle.right(180)
    turtle.forward(50)
    turtle.right(90)
    turtle.forward(50)
    turtle.right(90)
    turtle.forward(50)
    turtle.right(90)
    turtle.color(str(bg.get()))
    turtle.forward(100)
    turtle.left(90)


def printG(color):
    turtle.color(color)
    turtle.forward(50)
    turtle.left(180)
    turtle.forward(50)
    turtle.right(90)
    turtle.forward(100)
    turtle.right(90)
    turtle.forward(50)
    turtle.right(90)
    turtle.color(str(bg.get()))
    turtle.forward(50)
    turtle.color(color)
    turtle.forward(50)
    turtle.left(90)

def printH(color):
    turtle.color(color)
    turtle.left(90)
    turtle.forward(50)
    turtle.right(90)
    turtle.forward(50)
    turtle.right(180)
    turtle.forward(50)
    turtle.right(90)
    turtle.forward(50)
    turtle.right(90)
    turtle.color(str(bg.get()))
    turtle.forward(50)
    turtle.right(90)
    turtle.color(color)
    turtle.forward(100)
    turtle.left(90)


def printI(color):
    turtle.color(color)
    turtle.forward(50)
    turtle.left(180)
    turtle.forward(25)
    turtle.right(90)
    turtle.forward(100)
    turtle.left(90)
    turtle.forward(25)
    turtle.left(180)
    turtle.forward(50)
    turtle.color(str(bg.get()))
    turtle.right(90)
    turtle.forward(100)
    turtle.left(90)

def printJ(color):
    turtle.left(90)
    turtle.forward(50)
    turtle.left(180)
    turtle.color(color)
    turtle.forward(50)
    turtle.left(90)
    turtle.forward(25)
    turtle.left(90)
    turtle.forward(100)
    turtle.left(90)
    turtle.forward(25)
    turtle.left(180)
    turtle.forward(50)
    turtle.color(str(bg.get()))
    turtle.right(90)
    turtle.forward(100)
    turtle.left(90)


def printK(color):
    turtle.color(color)
    turtle.left(90)
    turtle.forward(100)
    turtle.left(180)
    turtle.forward(50)
    turtle.left(135)
    turtle.forward(70.71)
    turtle.left(180)
    turtle.forward(70.71)
    turtle.left(90)
    turtle.forward(70.71)
    turtle.left(45)

def printL(color):
    turtle.left(90)
    turtle.forward(100)
    turtle.color(color)
    turtle.left(180)
    turtle.forward(100)
    turtle.left(90)
    turtle.forward(50)


def printM(color):
    turtle.color(color)
    turtle.left(90)
    turtle.forward(100)
    turtle.right(135)
    turtle.forward(55.90)
    turtle.left(90)
    turtle.forward(55.90)
    turtle.right(135)
    turtle.forward(100)
    turtle.left(90)


def printN(color):
    turtle.color(color)
    turtle.left(90)
    turtle.forward(100)
    turtle.right(150)
    turtle.forward(115.70)
    turtle.left(150)
    turtle.forward(100)
    turtle.left(180)
    turtle.forward(100)
    turtle.left(90)

def printO(color):
    turtle.left(90)
    turtle.forward(5)
    turtle.color(color)
    turtle.forward(90)
    turtle.right(45)
    turtle.forward(7.07)
    turtle.right(45)
    turtle.forward(40)
    turtle.right(45)
    turtle.forward(7.07)
    turtle.right(45)
    turtle.forward(90)
    turtle.right(45)
    turtle.forward(7.07)
    turtle.right(45)
    turtle.forward(40)
    turtle.right(45)
    turtle.forward(7.07)
    turtle.right(180)
    turtle.forward(7.07)
    turtle.left(45)
    turtle.forward(40)
    turtle.color(str(bg.get()))
    turtle.forward(5)

def printP(color):
    turtle.color(color)
    turtle.left(90)
    turtle.forward(100)
    turtle.right(90)
    turtle.forward(45)
    turtle.right(45)
    turtle.forward(7.07)
    turtle.right(45)
    turtle.forward(40)
    turtle.right(45)
    turtle.forward(7.07)
    turtle.right(45)
    turtle.forward(45)
    turtle.left(90)
    turtle.forward(50)
    turtle.left(90)
    turtle.color(str(bg.get()))
    turtle.forward(50)

def printQ(color):
    turtle.left(90)
    turtle.forward(10)
    turtle.color(color)
    turtle.forward(80)
    turtle.right(45)
    turtle.forward(14.14)
    turtle.right(45)
    turtle.forward(30)
    turtle.right(45)
    turtle.forward(14.14)
    turtle.right(45)
    turtle.forward(80)
    turtle.right(45)
    turtle.forward(14.14)
    turtle.right(45)
    turtle.forward(30)
    turtle.right(45)
    turtle.forward(14.14)
    turtle.right(180)
    turtle.forward(14.14)
    turtle.left(45)
    turtle.forward(30)
    turtle.left(45)
    turtle.forward(7.07)
    turtle.left(90)
    turtle.forward(7.07)
    turtle.left(180)
    turtle.forward(14.14)
    turtle.left(180)
    turtle.forward(7.07)
    turtle.left(90)
    turtle.forward(7.07)
    turtle.left(135)
    turtle.color(str(bg.get()))
    turtle.forward(5)

def printR(color):
    turtle.color(color)
    turtle.left(90)
    turtle.forward(100)
    turtle.right(90)
    turtle.forward(45)
    turtle.right(45)
    turtle.forward(7.07)
    turtle.right(45)
    turtle.forward(40)
    turtle.right(45)
    turtle.forward(7.07)
    turtle.right(45)
    turtle.forward(45)
    turtle.left(180)
    turtle.forward(20)
    turtle.right(60)
    turtle.forward(58.30)
    turtle.left(60)

def printS(color):
    turtle.color(color)
    turtle.forward(45)
    turtle.left(45)
    turtle.forward(7.07)
    turtle.left(45)
    turtle.forward(40)
    turtle.left(45)
    turtle.forward(7.07)
    turtle.left(45)
    turtle.forward(40)
    turtle.right(45)
    turtle.forward(7.07)
    turtle.right(45)
    turtle.forward(40)
    turtle.right(45)
    turtle.forward(7.07)
    turtle.right(45)
    turtle.forward(45)
    turtle.color(str(bg.get()))
    turtle.forward(5)
    turtle.right(90)
    turtle.forward(100)
    turtle.right(90)
    turtle.forward(5)
    turtle.left(180)

def printT(color):
    turtle.forward(30)
    turtle.left(90)
    turtle.color(color)
    turtle.forward(100)
    turtle.left(90)
    turtle.forward(30)
    turtle.left(180)
    turtle.forward(60)
    turtle.color(str(bg.get()))
    turtle.right(90)
    turtle.forward(100)
    turtle.left(90)

def printU(color):
    turtle.forward(5)
    turtle.color(color)
    turtle.left(135)
    turtle.forward(7.07)
    turtle.right(45)
    turtle.forward(95)
    turtle.left(180)
    turtle.forward(95)
    turtle.left(45)
    turtle.forward(7.07)
    turtle.left(45)
    turtle.forward(40)
    turtle.left(45)
    turtle.forward(7.07)
    turtle.left(45)
    turtle.forward(95)
    turtle.left(180)
    turtle.forward(95)
    turtle.right(45)
    turtle.forward(7.07)
    turtle.left(135)
    turtle.color(str(bg.get()))
    turtle.forward(5)

def printV(color):
    turtle.forward(25)
    turtle.color(color)
    turtle.left(135)
    turtle.forward(55.90)
    turtle.right(45)
    turtle.forward(50)
    turtle.left(180)
    turtle.forward(50)
    turtle.left(45)
    turtle.forward(55.90)
    turtle.left(90)
    turtle.forward(55.90)
    turtle.left(45)
    turtle.forward(50)
    turtle.left(180)
    turtle.forward(50)
    turtle.color(str(bg.get()))
    turtle.forward(50)
    turtle.left(90)

def printW(color):
    turtle.color(color)
    turtle.left(90)
    turtle.forward(100)
    turtle.left(180)
    turtle.forward(100)
    turtle.left(135)
    turtle.forward(55.90)
    turtle.right(90)
    turtle.forward(55.90)
    turtle.left(135)
    turtle.forward(100)
    turtle.left(180)
    turtle.forward(100)
    turtle.left(90)

def printX(color):
    turtle.forward(50)
    turtle.color(color)
    turtle.left(116.551)
    turtle.forward(111.80)
    turtle.left(180)
    turtle.forward(55.90)
    turtle.right(53.102)
    turtle.forward(55.90)
    turtle.left(180)
    turtle.forward(111.80)
    turtle.right(153.449)
    turtle.color(str(bg.get()))
    turtle.forward(100)
    turtle.left(90)

def printY(color):
    turtle.forward(25)
    turtle.color(color)
    turtle.left(90)
    turtle.forward(50)
    turtle.left(40)
    turtle.forward(65)
    turtle.left(180)
    turtle.forward(65)
    turtle.left(100)
    turtle.forward(65)
    turtle.left(180)
    turtle.forward(65)
    turtle.left(40)
    turtle.forward(50)
    turtle.left(90)
    turtle.color(str(bg.get()))
    turtle.forward(30)

def printZ(color):
    turtle.color(color)
    turtle.left(63.45)
    turtle.forward(111.80)
    turtle.left(116.55)
    turtle.forward(50)
    turtle.left(180)
    turtle.forward(50)
    turtle.right(116.551)
    turtle.forward(111.80)
    turtle.left(116.55)
    turtle.forward(50)

def printNewLine():
    turtle.color(str(bg.get()))
    turtle.right(90)
    turtle.forward(10)
    turtle.left(90)
    turtle.setx(-200)

    turtle.sety(turtle.ycor()-150)

def printData():

    # switcher = {
    #     'A': printA(str(fg.get())),
    #     'B': printB(str(fg.get())),
    #     'C': printC(str(fg.get())),
    #     'D': printD(str(fg.get())),
    #     'E': printE(str(fg.get())),
    #     'F': printF(str(fg.get())),
    #     'G': printG(str(fg.get())),
    #     'H': printH(str(fg.get())),
    #     'I': printI(str(fg.get())),
    #     'J': printJ(str(fg.get())),
    #     'K': printK(str(fg.get())),
    #     'L': printL(str(fg.get())),
    #     'M': printM(str(fg.get())),
    #     'N': printN(str(fg.get())),
    #     'O': printO(str(fg.get())),
    #     'P': printP(str(fg.get())),
    #     'Q': printQ(str(fg.get())),
    #     'R': printR(str(fg.get())),
    #     'S': printS(str(fg.get())),
    #     'T': printT(str(fg.get())),
    #     'U': printU(str(fg.get())),
    #     'V': printV(str(fg.get())),
    #     'W': printW(str(fg.get())),
    #     'X': printX(str(fg.get())),
    #     'Y': printY(str(fg.get())),
    #     'Z': printZ(str(fg.get())),
    #
    # }
    turtle.color(str(bg.get()))
    turtle.setx(-300)
    turtle.sety(200)
    turtle.speed(3)
    turtle.width(int(font.get()))
    turtle.bgcolor(str(bg.get()))
    print(str(bg.get()))
    print(str(fg.get()))
    print(str(txt.get()))
    txtnew = str(txt.get()).upper()
    print(txtnew)
    # printA(str(fg.get()))
    # printBlank()
    # printBlank()
    # printZ(str(fg.get()))

    for i in txtnew:
        if turtle.xcor() > 500:
            printNewLine()
        if i == 'A':
            print("inside")
            printA(str(fg.get()))
        elif i == 'B':
            printB(str(fg.get()))
        elif i == 'C':
            printC(str(fg.get()))
        elif i == 'D':
            printD(str(fg.get()))
        elif i == 'E':
            printE(str(fg.get()))
        elif i == 'F':
            printF(str(fg.get()))
        elif i == 'G':
            printG(str(fg.get()))
        elif i == 'H':
            printH(str(fg.get()))
        elif i == 'I':
            printI(str(fg.get()))
        elif i == 'J':
            printJ(str(fg.get()))
        elif i == 'K':
            printK(str(fg.get()))
        elif i == 'L':
            printL(str(fg.get()))
        elif i == 'M':
            printM(str(fg.get()))
        elif i == 'N':
            printN(str(fg.get()))
        elif i == 'O':
            printO(str(fg.get()))
        elif i == 'P':
            printP(str(fg.get()))
        elif i == 'Q':
            printQ(str(fg.get()))
        elif i == 'R':
            printR(str(fg.get()))
        elif i == 'S':
            printS(str(fg.get()))
        elif i == 'T':
            printT(str(fg.get()))
        elif i == 'U':
            printU(str(fg.get()))
        elif i == 'V':
            printV(str(fg.get()))
        elif i == 'W':
            printW(str(fg.get()))
        elif i == 'X':
            printX(str(fg.get()))
        elif i == 'Y':
            printY(str(fg.get()))
        elif i == 'Z':
            printZ(str(fg.get()))
        elif i == ' ':
            printBlank()
        printBlank()


    turtle.done()




root = Tk()
root.title("I'll do what you ask me to!")
mainframe = ttk.Frame(root,padding = "25 25 25 25")
mainframe.grid(column=0,row=0, sticky = (N,W,E,S))
mainframe.columnconfigure(0,weight = 1)
mainframe.rowconfigure(0, weight= 1)
txt = StringVar()
bg = StringVar()
fg = StringVar()
font = StringVar()
font.set(10)
bg.set("white")
ttk.Label(mainframe, text= "Text:").grid(column = 1, row = 1, sticky = (W,E))
textEntry = ttk.Entry(mainframe, width = 7,textvariable = txt)
textEntry.grid(column =1, row = 2, sticky = (W,E))

ttk.Label(mainframe, text = "ForeGround Color:").grid(column=1,row =3,sticky = (W,E))
fgEntry = ttk.Entry(mainframe, width = 7,textvariable = fg)
fgEntry.grid(column =1, row = 4, sticky = (W,E))

ttk.Label(mainframe, text = "BackGround Color:").grid(column=1,row =5,sticky = (W,E))
bgEntry = ttk.Entry(mainframe, width = 7,textvariable = bg)
bgEntry.grid(column =1, row = 6, sticky = (W,E))

ttk.Label(mainframe, text = "Font Size:").grid(column=1,row =7,sticky = (W,E))
fontEntry = ttk.Entry(mainframe, width = 7,textvariable = font)
fontEntry.grid(column =1, row = 8, sticky = (W,E))

ttk.Button(mainframe,text="Okay?", command = printData).grid(column= 1, row = 9, sticky = (W,E))
for child in mainframe.winfo_children():
    child.grid_configure(padx=5,pady=5)
textEntry.focus()
root.mainloop()







